﻿using System.Data.SqlClient;
using SemesterTwo.Models;
using Microsoft.Extensions.Configuration;
using System.Threading.Tasks;

namespace SemesterTwo.Services
{
    public class CustomerService
    {
        private readonly IConfiguration _configuration;

        public CustomerService(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public async Task InsertCustomerAsync(CustomerProfile profile)
        {
            var connectionString = _configuration.GetConnectionString("DefaultConnection");
            var query = @"INSERT INTO Customers (FirstName, LastName, Email, PhoneNumber, Address, City, State, ZipCode, CreatedAt)
                          VALUES (@FirstName, @LastName, @Email, @PhoneNumber, @Address, @City, @State, @ZipCode, @CreatedAt)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);

                command.Parameters.AddWithValue("@FirstName", profile.FirstName);
                command.Parameters.AddWithValue("@LastName", profile.LastName);
                command.Parameters.AddWithValue("@Email", profile.Email);
                command.Parameters.AddWithValue("@PhoneNumber", profile.PhoneNumber);
                command.Parameters.AddWithValue("@Address", profile.Address);
                command.Parameters.AddWithValue("@City", profile.City);
                command.Parameters.AddWithValue("@State", profile.State);
                command.Parameters.AddWithValue("@ZipCode", profile.ZipCode);
                command.Parameters.AddWithValue("@CreatedAt", profile.CreatedAt);

                connection.Open();
                await command.ExecuteNonQueryAsync();
            }
        }
    }
}
    

